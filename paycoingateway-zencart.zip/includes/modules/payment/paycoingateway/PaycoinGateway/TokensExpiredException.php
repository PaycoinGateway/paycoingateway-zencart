<?php

class PaycoinGateway_TokensExpiredException extends PaycoinGateway_Exception
{
}
