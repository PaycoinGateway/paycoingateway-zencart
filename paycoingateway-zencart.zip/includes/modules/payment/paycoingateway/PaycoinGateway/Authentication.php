<?php

abstract class PaycoinGateway_Authentication
{
    abstract public function getData();
}