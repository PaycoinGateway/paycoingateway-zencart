<?php

class PaycoinGateway_ConnectionException extends PaycoinGateway_Exception
{
}
