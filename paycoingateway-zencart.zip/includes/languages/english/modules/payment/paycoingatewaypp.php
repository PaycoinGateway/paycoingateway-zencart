<?php

// Coinbase payment plugin
define('MODULE_PAYMENT_PAYCOINGATEWAY_TEXT_TITLE', 'Paycoin (powered by PaycoinGateway.com)');
define('MODULE_PAYMENT_PAYCOINGATEWAY_TEXT_DESCRIPTION', 'Accept Paycoin with PaycoinGateway.com.');
define('MODULE_PAYMENT_PAYCOINGATEWAY_TEXT_CHECKOUT', 'Paycoin');